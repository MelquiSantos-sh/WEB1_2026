# Box-model
4 atividades realizadas para prendizado 
[04 - BOX MODEL (1).pdf](https://github.com/user-attachments/files/26482867/04.-.BOX.MODEL.1.pdf)




